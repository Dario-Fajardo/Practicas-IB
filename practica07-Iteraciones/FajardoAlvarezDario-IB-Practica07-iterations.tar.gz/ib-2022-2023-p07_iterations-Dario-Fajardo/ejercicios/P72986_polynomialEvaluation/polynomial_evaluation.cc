/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es  
  * @date Nov 14 2020
  * @brief this program reads a polynomial p(x) and a number x
  * computes p(x)
  *
  * @bug no bugs known 
  * @see https://jutge.org/problems/P96767_en
  */

#include <iostream>
#include <iomanip>
 
int main () {
  double point;
  std::cin >> point;
  double number;
  double sumator{0};
  while (std::cin >> number){
   sumator = (sumator * point) + number;
  }
  std::cout << std::fixed << std::setprecision(4) << sumator << std::endl;
} 
