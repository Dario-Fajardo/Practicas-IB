/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es  
  * @date Nov 13 2022
  * @brief prints the first N numbers of the fibonacci sequence 
  * @bug no bugs known
  */

#include <iostream>

/**
  * Prints every number int the fibonacci sequence until reching a
  * certain value.
  *
  * @param position the position of the last number that is going to be printed
  */
void fibonacci(int position) {
  int number_one{0}, number_two{1}, number_three{1};
  std::cout << 0 << " ";
  for (int i{1}; i < position; ++i) {
    number_three = number_two + number_one;
    if (number_three == 1 && position != 2) {
      std::cout << 1 << " ";
      ++i;
    }
    std::cout << number_three << " ";
    number_one = number_two;
    number_two = number_three;
  }
}

int main() {
  int fibonacci_position;
  std::cin >> fibonacci_position;
  fibonacci(fibonacci_position);
  std::cout << std::endl;
  return 0;
}
