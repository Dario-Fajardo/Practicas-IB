/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es  
  * @date 13 Nov 2022
  * @brief This program converts any given binary number into decimal
  * @bug there is not any known bugs
  */

#include <iostream>
#include <cmath>

/**
  * Converts binary numbers into decimal and prints them
  * 
  * @param binary The binary number to be converted 
  */
void DecimalConversor(int binary) {
  int exp{0}, digit{0}, decimal{0};
  while(static_cast<double>(binary) / 10 != 0.00000000000) {
    digit = binary % 10;
    decimal += digit * pow(2.0,exp);
    ++exp;
    binary /= 10;
  }
  std::cout << decimal << std::endl;
}

int main() {
  int number;
  std::cin >> number;
  DecimalConversor(number);
}
