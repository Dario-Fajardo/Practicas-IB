var indexSectionsWithContent =
{
  0: "bdm",
  1: "b",
  2: "dm",
  3: "b"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Pages"
};

