/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es  
  * @date Nov 12 2022
  * @brief user gives an integer number and the program sums it digits
  * @bug no bugs known
  * @file digits_sum.cc
  */

#include <iostream>

/**
  * Sum the digits of an integer and prints it value by console
  * @param first_number the result of the sum
  * @param second_number the number entered by user
  */
void SumDigits(int first_number, int second_number) {
  while(second_number > 0) {
    /** We get the digits of the number and we sum them until we have the final
      * value.
      */
    first_number = first_number + second_number % 10; 
    second_number = second_number / 10; 
  }
  std::cout << first_number << std::endl;
}

int main() {
  int number{0};
  int result{0};
  std::cin >> number;
  SumDigits(result, number);
  return 0;
}
