var searchData=
[
  ['isleap_1',['IsLeap',['../leap-year_8cc.html#a4007a166670e54938cb79e246cdf632a',1,'leap-year.cc']]]
];
