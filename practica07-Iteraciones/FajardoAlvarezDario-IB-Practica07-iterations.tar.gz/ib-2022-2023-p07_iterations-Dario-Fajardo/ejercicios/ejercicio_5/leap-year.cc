/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es  
  * @date Nov 13 2022
  * @brief This program tells the user if the entered year its leap or not
  * @bug not known bugs
  */

#include <iostream>

/**
  * It calculates if a year is leap or not
  * 
  * @param year The year that could be leap or not
  */
void IsLeap(int year) {
  if (year % 400 == 0) {
    std::cout << "YES" << std::endl;
  } else if (year % 4 == 0 && year % 100 != 0) {
    std::cout << "YES" << std::endl;
  } else {
    std::cout << "NO" << std::endl;
  }
}

int main() {
  int year;
  std::cin >> year;
  IsLeap(year); 
}
