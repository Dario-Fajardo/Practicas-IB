/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es  
  * @date Nov 14 2020
  * @brief this program reads a polynomial p(x) and a number x
  * computes p(x)
  *
  * @bug no bugs known 
  * @see https://jutge.org/problems/P96767_en
  */

#include <iostream>
#include <iomanip>
#include <cmath>

int main() {
  double x_value, coeficient, result = 0.0;
  std::cin >> x_value;
  int exponent{0};
  while (std::cin >> coeficient) {
    result += coeficient * pow(x_value, iterator);
    ++iterator;
  }
  std::cout << std::fixed << std::setprecision(4) << result << std::endl;
  return 0;
}
