/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es  
  * @date Nov 14 2022
  * @brief this program reverses any number given by user
  * @bug no bugs known
  * @see https://jutge.org/problems/P50327_en
  */

#include <iostream>

int main() {
  int number;
  std::cin >> number;
  if (number == 0) {
    std::cout << 0; 
  }
  while (number != 0) {
    int digit;
    digit = number % 10;
    std::cout << digit;
    number = number / 10;
  }
  std::cout << std::endl;
  return 0;
}
