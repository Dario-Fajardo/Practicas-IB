var searchData=
[
  ['binary_2ecc_4',['binary.cc',['../binary_8cc.html',1,'']]]
];
