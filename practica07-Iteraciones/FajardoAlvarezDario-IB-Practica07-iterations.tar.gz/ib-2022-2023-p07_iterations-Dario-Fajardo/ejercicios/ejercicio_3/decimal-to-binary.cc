/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es  
  * @date Nov 13 2022
  * @brief this program traduces any given number into binary
  * @bug no bugs known
  */

#include <iostream>
#include <cmath>

/**
  * Decimal to binary converter
  *
  * @param number the decimal number that is going to be converted into binary
  */
void BinaryNumber(int number, int binary) {
  int digit{0}, exp{0};
  while(number != 0) {
    digit = number % 2;
    binary += digit * pow(10.0, exp);
    number = number / 2;
    ++exp;
  }
  binary = binary + number * pow(10.0,exp);
  std::cout << binary << std::endl;
}

int main() {
  int user_number{0}, user_binary{0};
  std::cin >> user_number;
  BinaryNumber(user_number, user_binary);
  std::cout << std::endl;
}
