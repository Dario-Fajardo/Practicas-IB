/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es
  * @date 29 Dic 2022
  * @brief Este programa permite realizar diversos cálculos con números enteros
  */

#include "Compute_int.h"
#include <iostream>
#include <stdlib.h>
#include <cmath>

/**
  * @brief Esta funcion calcula el factorial de un número
  * @param number: el numero del que se calculará el factorial
  * @return el resultado de dicha operación 
  */
int ComputeInt::Factorial(int number) {
  int result{1};
  for (int i{number}; i >=1; --i) {
    result = i * result;
  }
  return result;
}

/**
  * @brief Esta funcion calcula el sumatorio de todos los números hasta el 
  *        introducido
  * @param last_number: el número hasta el que se calculará este sumatorio
  * @return el resultado de dicho sumatorio
  */
int ComputeInt::SumSerie(int last_number) {
  int result{0};
  for (int i{0}; i <= last_number; ++i) {
    result = result + i;
  }
  return result;
}

/**
  * @brief Esta funcion calcula si un número es primo o no
  * @param number: el numero en cuestión
  * @return true si el número es primo, false si no.
  */
bool ComputeInt::IsPrime(int number) {
  int sum_of_divisors{0};
  for (int i{1}; i <= number; ++i) {
    int remainder{number % i};
    if ((remainder == 0)) {
      sum_of_divisors = sum_of_divisors + i;
    }
  }
  if (sum_of_divisors == (number + 1)) {
    return true;
  } else {
    return false;
  }
}

/**
  * @brief Esta funcion calcula la suma de los digitos de un número
  * @param number: el numero en cuestión
  * @return true si el número es primo perfecto, false si no.
  */
int ComputeInt::SumOfDigits(int number) {
  int sum = 0;
  while (number > 0) {
    sum += number % 10;
    number /= 10;
  }
  return sum;
}

/**
  * @brief Esta funcion calcula si un número es primo prefecto o no
  * @param number: el numero en cuestión
  * @return true si el número es primo perfecto, false si no.
  */
bool ComputeInt::IsPerfectPrime (int number) {
  if (number < 10) {
    return IsPrime(number);
  } else if (!IsPrime(number)) {
    return false;
  } else {
    return IsPerfectPrime(SumOfDigits(number));
  }
}

/**
  * @brief Esta funcion calcula si dos números son primos relativos o no
  * @param first_number: el primero de los números
  * @param second_number: el segundo de los números
  * @return true si los números son primos relativos, false si no.
  */
bool ComputeInt::AreRelativePrimes(int first_number, int second_number) {
  int box{0};
  if (second_number > first_number) {
    box = second_number;
    second_number = first_number;
    first_number = box;
  }
  int sum_of_common_divisors{0};
  for (int i{1}; i <= second_number; ++i) {
    if ((first_number % i == 0) && (second_number % i == 0)) {
      sum_of_common_divisors += i;
    }
  }
  if (sum_of_common_divisors == 1) {
    return true;
  } else {
    return false;
  }
}

/**
  * @brief Esta función cuenta el número de digitos de un número
  * @param number: el numero en cuestión
  * @return la cantidad de dígitos del número introducido
  */
int ComputeInt::NumberOfDigits(int number) const {
  int number_of_digits{0};
  while (number < 0) {
    number /= 10;
    number_of_digits += 1;
  }
  return number_of_digits;
}

/**
  * @brief Esta función comprueba si un número es especial o no
  * @param number: el numero en cuestión
  * @return true si es especial, false si no.
  */
bool ComputeInt::IsSpecialNumber(int number) const {
  int sum_of_powers{0};
  int number_of_digits{NumberOfDigits(number)};
  while (number > 0) {
    sum_of_powers += pow((number % 10), number_of_digits);
    number /= 10;
  }
  if (sum_of_powers == number) {
    return true;
  } else {
    return false;
  }
}

/**
  * @brief Esta funcion imprime por consola el funcionamiento del programa y
  *        lo que hará
  */
void Funcionamiento() {
  std::cout << "Este programa requerirá de dos números enteros introducidos ";
  std::cout << "por consola, realizará varios cálculos sobre cada uno de ";
  std::cout << "ellos y comprobará si son primos relativos." << std::endl;
  std::cout << std::endl;
}


/**
  * @brief Esta funcion comprueba que se han introducido parámetros válidos por
  *        línea de comandos
  * @param argc: el número de parámetros introducido
  * @return true si todo es correcto, false si no.
  */
bool ParametrosCorrectos(int argc) {
  if (argc != 3) {
    return false;
  }
  return true;
}

