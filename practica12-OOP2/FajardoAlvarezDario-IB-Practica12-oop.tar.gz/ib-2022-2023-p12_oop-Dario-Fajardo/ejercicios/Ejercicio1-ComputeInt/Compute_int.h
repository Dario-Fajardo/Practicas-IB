/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es
  * @date 29 Dic 2022
  * @brief Este programa permite realizar diversos cálculos con números enteros
  */

 #include <iostream>
 #include <stdlib.h>
 
class ComputeInt {
 public:
  int Factorial(int number);
  int SumSerie(int last_number);
  bool IsPrime(int number);
  bool IsPerfectPrime(int number);
  bool AreRelativePrimes(int first_number, int second_number);
  bool IsSpecialNumber(const int number) const;
 private:
    int SumOfDigits(int number);
    int NumberOfDigits(int number) const;
};

void Funcionamiento();
bool ParametrosCorrectos(int argc);