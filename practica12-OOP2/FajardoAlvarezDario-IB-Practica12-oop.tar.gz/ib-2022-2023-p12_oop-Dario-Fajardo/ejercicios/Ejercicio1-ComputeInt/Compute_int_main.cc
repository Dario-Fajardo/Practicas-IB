/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es
  * @date 29 Dic 2022
  * @brief Este programa permite realizar diversos cálculos con números enteros
  */

#include "Compute_int.h"
#include <iostream>
#include <stdlib.h>

int main(int argc, char* argv[]) {
  ComputeInt computation;
  Funcionamiento();
  if (!ParametrosCorrectos(argc)) {
    std::cout << "Recuerde introducir dos números enteros para que el ";
    std::cout << "programa funcione correctamente..." << std::endl << std::endl;
  }
  int first_number{atoi(argv[1])};
  int second_number{atoi(argv[2])};

  std::cout << "Factorial del primer número: "; 
  std::cout << computation.Factorial(first_number) << std::endl;
  std::cout << "Sumatorio del primer número: "; 
  std::cout << computation.SumSerie(first_number) << std::endl;

  std::cout << "Factorial del segundo número: "; 
  std::cout << computation.Factorial(second_number) << std::endl;
  std::cout << "Sumatorio del segundo número: "; 
  std::cout << computation.SumSerie(second_number) << std::endl;

  if (computation.IsPrime(first_number)) {
    std::cout << "El primer número es primo" << std::endl;
    if (computation.IsPerfectPrime(first_number)) {
      std::cout << "Además, es primo perfecto" << std::endl;
    }
  } else {
    std::cout << "El primer número no es primo" << std::endl;
  }

  if (computation.IsPrime(second_number)) {
    std::cout << "El segundo número es primo" << std::endl;
    if (computation.IsPerfectPrime(second_number)) {
      std::cout << "Además, es primo perfecto" << std::endl;
    }
  } else {
    std::cout << "El segundo número no es primo" << std::endl;
  }

  if (computation.AreRelativePrimes(first_number, second_number)) {
    std::cout << "Ambos números son primos relativos" << std::endl;
  } else {
    std::cout << "No son primos relativos" << std::endl;
  }

  if (computation.IsSpecialNumber(first_number)) {
    std::cout << "el " << first_number << " es un número especial" << std::endl;
  } else {
    std::cout << "no es un número especial" << std::endl;
  }

  std::cout << std::endl;
}