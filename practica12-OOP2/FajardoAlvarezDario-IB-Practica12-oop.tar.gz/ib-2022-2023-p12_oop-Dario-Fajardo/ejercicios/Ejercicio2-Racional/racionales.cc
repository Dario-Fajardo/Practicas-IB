/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es
  * @date 30 Dic 2022
  * @brief Este programa permite tratar con números racionales y operar 
  *        con ellos
  */

 #include "racionales.h"


/**
  * @brief Constructor por defecto de la clase Racional 
  */
Racional::Racional() {
  numerador_ = 0;
  denominador_ = 0;
}

/**
  * @brief Constructor parametrizado de la clase Racional
  * @param numerador: el numerador del número racional
  * @param denominador: el denominador del número racional
  */
Racional::Racional(int numerador, int denominador) {
  numerador_ = numerador;
  denominador_ = denominador;
}

/**
  * @brief getter del atributo numerador_ de la clase racional
  * @return el valor del atributo numerador_ 
  */
int Racional::GetNumerador() {
  return numerador_;
}

/**
  * @brief getter del atributo denominador_ de la clase racional
  * @return el valor del atributo denominador_ 
  */
int Racional::GetDenominador() {
  return denominador_;
}

/**
  * @brief sobrecarga del operador suma para números de la clase Racional
  * @param kRacional: el número con el que se va a sumar el racional
  * @return el resultado de la suma
  */
Racional Racional::operator+(const Racional& kRacional) const {
  if (denominador_ == kRacional.denominador_) {
    int denominador{denominador_};
    int numerador{numerador_ + kRacional.numerador_};
    Racional resultado{numerador, denominador};
    return resultado; 
  } else {
    int minimo_comun_multiplo{MinimoComunMultiplo(denominador_, 
    kRacional.denominador_)};
    int denominador{minimo_comun_multiplo};
    int numerador{((numerador_ * minimo_comun_multiplo) / denominador_) + 
    ((kRacional.numerador_ * minimo_comun_multiplo) / kRacional.denominador_)};
    Racional resultado{numerador, denominador};
    return resultado;
  }
}


/**
  * @brief sobrecarga del operador resta para números de la clase Racional
  * @param kRacional: el número con el que se va a restar el racional
  * @return el resultado de la resta
  */
Racional Racional::operator-(const Racional& kRacional) const {
  if (denominador_ == kRacional.denominador_) {
    int denominador{denominador_};
    int numerador{numerador_ - kRacional.numerador_};
    Racional resultado{numerador, denominador};
    return resultado; 
  } else {
    int minimo_comun_multiplo{MinimoComunMultiplo(denominador_, 
    kRacional.denominador_)};
    int denominador{minimo_comun_multiplo};
    int numerador{((numerador_ * minimo_comun_multiplo) / denominador_) - 
    ((kRacional.numerador_ * minimo_comun_multiplo) / kRacional.denominador_)};
    Racional resultado{numerador, denominador};
    return resultado;
  }
}

/**
  * @brief sobrecarga del operador multiplicación para números de la clase 
  *        Racional
  * @param kRacional: el número con el que se va a multiplicar el racional
  * @return el resultado de la multiplicación
  */
Racional Racional::operator*(const Racional& kRacional) const {
  int numerador{numerador_ * kRacional.numerador_};
  int denominador{denominador_ * kRacional.denominador_};
  Racional resultado{numerador, denominador};
  return resultado;
}

/**
  * @brief sobrecarga del operador división para números de la clase 
  *        Racional
  * @param kRacional: el número con el que se va a dividir el racional
  * @return el resultado de la división
  */
Racional Racional::operator/(const Racional& kRacional) const {
  int numerador{numerador_ * kRacional.denominador_};
  int denominador{denominador_ * kRacional.denominador_};
  Racional resultado{numerador, denominador};
  return resultado;
}

/**
  * @brief sobrecarga del operador menor que para variables de la clase Racional
  * @param kRacional: el número con el que se va a comparar el racional
  * @return true si es menor, false si es mayor o igual
  */
bool Racional::operator<(const Racional& kRacional) const {
  double primer_valor_decimal{static_cast<double>(numerador_ / denominador_)};
  double segundo_valor_decimal{static_cast<double>(kRacional.numerador_ / 
  kRacional.denominador_)};
  if (primer_valor_decimal < segundo_valor_decimal) {
    return true;
  } else {
    return false;
  }
}

/**
  * @brief sobrecarga del operador mayor que para variables de la clase Racional
  * @param kRacional: el número con el que se va a comparar el racional
  * @return true si es mayor, false si es menor o igual
  */
bool Racional::operator>(const Racional& kRacional) const {
  double primer_valor_decimal{static_cast<double>(numerador_ / denominador_)};
  double segundo_valor_decimal{static_cast<double>(kRacional.numerador_ / 
  kRacional.denominador_)};
  if (primer_valor_decimal > segundo_valor_decimal) {
    return true;
  } else {
    return false;
  }
}

/**
  * @brief sobrecarga del operador menor o igual que para variables de la 
  *        clase Racional
  * @param kRacional: el número con el que se va a comparar el racional
  * @return true si es menor o igual, false si es mayor
  */
bool Racional::operator<=(const Racional& kRacional) const {
  double primer_valor_decimal{static_cast<double>(numerador_ / denominador_)};
  double segundo_valor_decimal{static_cast<double>(kRacional.numerador_ / 
  kRacional.denominador_)};
  if (primer_valor_decimal <= segundo_valor_decimal) {
    return true;
  } else {
    return false;
  }
}

/**
  * @brief sobrecarga del operador mayor o igual que para variables de la 
  *        clase Racional
  * @param kRacional: el número con el que se va a comparar el racional
  * @return true si es mayor o igual, false si es menor
  */
bool Racional::operator>=(const Racional& kRacional) const {
  double primer_valor_decimal{static_cast<double>(numerador_ / denominador_)};
  double segundo_valor_decimal{static_cast<double>(kRacional.numerador_ / 
  kRacional.denominador_)};
  if (primer_valor_decimal >= segundo_valor_decimal) {
    return true;
  } else {
    return false;
  }
}

/**
  * @brief sobrecarga del operador igual que para variables de la 
  *        clase Racional
  * @param kRacional: el número con el que se va a comparar el racional
  * @return true si es igual, false si no
  */
bool Racional::operator==(const Racional& kRacional) const {
  double primer_valor_decimal{static_cast<double>(numerador_ / denominador_)};
  double segundo_valor_decimal{static_cast<double>(kRacional.numerador_ /
  kRacional.denominador_)};
  if (primer_valor_decimal == segundo_valor_decimal) {
    return true;
  } else {
    return false;
  }
}

/**
  * @brief sobrecarga del operador no es igual que para variables de la 
  *        clase Racional
  * @param kRacional: el número con el que se va a comparar el racional
  * @return true si es diferente, false si es igual
  */
bool Racional::operator!=(const Racional& kRacional) const {
  double primer_valor_decimal{static_cast<double>(numerador_ / denominador_)};
  double segundo_valor_decimal{static_cast<double>(kRacional.numerador_ / 
  kRacional.denominador_)};
  if (primer_valor_decimal != segundo_valor_decimal) {
    return true;
  } else {
    return false;
  }
}

/**
  * @brief sobrecarga del operador << para sacar variables de la clase Racional 
  *        por consola o por fichero
  * @param output: la salida
  * @param kRacional: el número con el que se va a restar el racional
  * @return el valor de la salida que podra ser utilizado para imprimir en 
  *         consola o por un fichero
  */
std::ostream& operator<<(std::ostream& output, const Racional& kRacional) {
  output << kRacional.numerador_ << "/" << kRacional.denominador_;
  return output;
}

std::istream& operator>>(std::istream& input, Racional& racional) {
  input >> racional.numerador_ >> racional.denominador_;
  return input;
}

/**
  * @brief comprueba que el número de parámetros introducido es el correcto
  * @param argc: número de parámetros pasado por línea de comandos
  * @return true si todo es correcto, false si no.
  */
bool ComprobarParametrosCorrectos(int argc) {
  if (argc != 3) {
    return false;
  } else {
    return true;
  }
}

/**
  * @brief imprime por consola el modo de uso del programa en caso de que se le 
  *        pida
  */
void ImprimeModoDeUso(){
  std::cout << "./racionales -- Números Racionales" << std::endl;
  std::cout << "Modo de uso: ./racionales fichero_entrada fichero_salida";
  std::cout << std::endl << std::endl << "fichero_entrada: Fichero de texto ";
  std::cout << "conteniendo líneas con un par de números racionales: `a/b c/d` ";
  std::cout << "separados por un espacio" << std::endl;
  std::cout << "fichero_salida:  Fichero de texto que contendrá líneas con las ";
  std::cout << "operaciones realizadas: `a/b + c/d = n/m" << std::endl;
  std::cout << std::endl;
}

/**
  * @brief función que calcula el M.C.M de dos números (utilizada para el 
  *        calculo del m.c.m en este programa)
  * @param first_number: el primero de los números
  * @param second_number: el segundo de los números
  * @return el M.C.M de ambos números
  */
int MaximoComunDivisor(int first_number, int second_number) {
  int maximo_comun_divisor{0};
  int numero_mayor{std::max(first_number, second_number)};
  int numero_menor{std::min(first_number, second_number)};
  while (numero_menor != 0) {
    maximo_comun_divisor = numero_menor;
    numero_menor = numero_mayor % numero_menor;
    numero_mayor = maximo_comun_divisor;
  }
  return maximo_comun_divisor;
}

/**
  * @brief función que calcula el m.c.m de dos números (utilizada para el 
  *        calculo de sumas y restas en este programa)
  * @param first_number: el primero de los números
  * @param second_number: el segundo de los números
  * @return el m.c.m de ambos números
  */
int MinimoComunMultiplo(int first_number, int second_number) {
  int numero_mayor{std::max(first_number, second_number)};
  int numero_menor{std::min(first_number, second_number)};
  int minimo_comun_multiplo{(numero_mayor / 
  MaximoComunDivisor(numero_mayor, numero_menor)) * numero_menor};
  return minimo_comun_multiplo;
}

/**
  * @brief convierte todo el texto de un fichero en una string (omitiendo '/')
  * @param kNombre_fichero: una string con el nombre del fichero pasado por 
  *                         referencia constante
  * @return una string con todo el contenido
  */
std::string FicheroEnString(const std::string& kNombre_fichero) {
  std::ifstream fichero{kNombre_fichero, std::ios::in};
  std::string texto;
  std::string linea;
  const char kEspacio{' '};
  while (getline(fichero, linea)) {
    for (const auto& caracter_actual : linea) {
      if (caracter_actual != '/') {
        texto += caracter_actual;
      }
    }
    texto += kEspacio;
    texto += kEspacio;
  }
  return texto;
}

/**
  * @brief separa los racionales introducidos en el archivo (ya convertido a 
  *        string) en pares de racionales los cuales van a ser operados entre sí
  * @param kNombre_fichero: el contenido del fichero pasado por la funcion 
  *                         FicheroEnString
  * @return una string con un par de racionales separados por espacio
  */
std::string SepararEnParesDeRacionales(std::string& entrada) {
  std::string par_de_racionales{""};
  const char kEspacio{' '};
  for (const auto& caracter_actual : entrada) {
    int longitud{static_cast<int>(par_de_racionales.length())};
    if ((caracter_actual == kEspacio) && (par_de_racionales[longitud] == kEspacio)) {
      return par_de_racionales;
    } else {
      par_de_racionales += caracter_actual;
    }
  }
  return par_de_racionales;
}