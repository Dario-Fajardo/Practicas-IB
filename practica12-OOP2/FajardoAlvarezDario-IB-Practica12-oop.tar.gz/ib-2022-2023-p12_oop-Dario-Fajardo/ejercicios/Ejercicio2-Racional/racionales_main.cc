/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es
  * @date 30 Dic 2022
  * @brief Este programa permite tratar con números racionales y operar 
  *        con ellos
  */

#include "racionales.h"

int main(int argc, char* argv[]) {
  if (!ComprobarParametrosCorrectos(argc)) {
    if (argc == 2) {
      std::string first_parameter{argv[1]};
      ImprimeModoDeUso();
      return EXIT_SUCCESS;
    } else {
      std::cout << "./racionales -- Números Racionales" << std::endl;
      std::cout << "Modo de uso: ./racionales fichero_entrada fichero_salida";
      std::cout << std::endl << "Pruebe ./racionales --help para más información";
      std::cout << std::endl;
      return EXIT_FAILURE;
    }
  }

  std::string nombre_fichero{argv[1]};
  std::string nombre_fichero_salida{argv[2]};
  std::ofstream fichero_salida{nombre_fichero_salida, std::ios::out};
  std::string contenido_fichero{FicheroEnString(nombre_fichero)};

  while(contenido_fichero != "") {
    int numerador1{0};
    int denominador1{0};
    int numerador2{0};
    int denominador2{0};
    std::string par_actual{SepararEnParesDeRacionales(contenido_fichero)};
    numerador1 = static_cast<int>(par_actual[0]) - 48;
    denominador1 = static_cast<int>(par_actual[1]) - 48;
    numerador2 = static_cast<int>(par_actual[3]) - 48;
    denominador2 = static_cast<int>(par_actual[4]) - 48;
    Racional racional1{numerador1, denominador1};
    Racional racional2{numerador2, denominador2};

    if ((racional1.GetDenominador() == 0) || racional2.GetDenominador() == 0) {
      std::cout << "Recuerde que un número racional no puede tener como "; 
      std::cout << "denominador el número 0, compruebe los valores intrducidos";
      std::cout << std::endl << std::endl;
      return EXIT_FAILURE;
    }
    
    Racional suma{racional1 + racional2};
    fichero_salida << racional1 << " + " << racional2 << " = " << suma;
    fichero_salida << std::endl;

    Racional resta{racional1 - racional2};
    fichero_salida << racional1 << " - " << racional2 << " = " << resta;
    fichero_salida << std::endl;

    Racional division{racional1 / racional2};
    fichero_salida << racional1 << " / " << racional2 << " = " << division;
    fichero_salida << std::endl;

    Racional producto{racional1 * racional2};
    fichero_salida << racional1 << " * " << racional2 << " = " << producto;
    fichero_salida << std::endl;
    
    contenido_fichero.erase(0, 7);
  }
  return 0;
}