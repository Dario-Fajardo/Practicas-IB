/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es
  * @date 30 Dic 2022
  * @brief Este programa permite tratar con números racionales y operar 
  *        con ellos
  */

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <cmath>

class Racional {
 public:
  Racional();
  Racional(const int kNumerador, const int kDenominador);
  int GetNumerador();
  int GetDenominador();
  Racional operator+(const Racional& kRacional) const;
  Racional operator-(const Racional& kRacional) const;
  Racional operator*(const Racional& kRacional) const;
  Racional operator/(const Racional& kRacional) const;
  bool operator<(const Racional& kRacional) const;
  bool operator>(const Racional& kRacional) const;
  bool operator>=(const Racional& kRacional) const;
  bool operator<=(const Racional& kRacional) const;
  bool operator==(const Racional& kRacional) const;
  bool operator!=(const Racional& kRacional) const;
  friend std::ostream& operator<<(std::ostream& output, 
  const Racional& kRacional);
  friend std::istream& operator>>(std::istream& input, Racional& racional);
 private:
  int numerador_;
  int denominador_;
};

bool ComprobarParametrosCorrectos(int argc);
void ImprimeModoDeUso();

int MaximoComunDivisor(int first_number, int second_number);
int MinimoComunMultiplo(int first_number, int second_number);
std::string FicheroEnString(const std::string& nombre_fichero);
std::string SepararEnParesDeRacionales(std::string& entrada);