/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es
  * @date 30 Dic 2022
  * @brief Crea un sistema de coordenadas y simula la existencia de un robot el 
  *        cual se podrá mover dandole direcciones
  * @see https://jutge.org/problems/P79784
  */

#include <iostream>
#include <vector>
#include <string>

typedef std::pair<int,int> Coordenadas;

class Robot {
 public:
  /// Constructores
  Robot();
  /// Getters
  Coordenadas GetCoordenadas() const;
  /// Movimiento
  void AvanzarNorte();
  void AvanzarSur();
  void AvanzarEste();
  void AvanzarOeste();
  void EjecutarSecuencia(const std::string& secuencia_de_movimientos); 
 private:
  Coordenadas posicion_{0, 0};
};

Robot::Robot() {
  posicion_ = {0, 0};
}

Coordenadas Robot::GetCoordenadas() const {
  return posicion_;
}

void Robot::AvanzarNorte() {
  int& y_coord{posicion_.second};
  --y_coord; 
}

void Robot::AvanzarSur() {
  int& y_coord{posicion_.second};
  ++y_coord; 
}

void Robot::AvanzarEste() {
  int& x_coord{posicion_.first};
  ++x_coord;
}

void Robot::AvanzarOeste() {
  int& x_coord{posicion_.first};
  --x_coord;
}

void Robot::EjecutarSecuencia(const std::string& secuencia_de_movimientos) {
  for (const auto& direccion_actual : secuencia_de_movimientos) {
    switch (direccion_actual) {
      case 'n':
        AvanzarNorte();
        break;
      case 's':
        AvanzarSur();
        break;
      case 'e':
        AvanzarEste();
        break;
      case 'w':
        AvanzarOeste();
        break;
    }
  }
}

int main() {
  Robot robot;
  std::string secuencia_de_movmientos;
  std::cin >> secuencia_de_movmientos;
  robot.EjecutarSecuencia(secuencia_de_movmientos);
  std::pair<int, int> posicion_final{robot.GetCoordenadas()};
  std::cout << "(" << posicion_final.first << ", " << posicion_final.second;
  std::cout << ")" << std::endl;
  return 0;
}