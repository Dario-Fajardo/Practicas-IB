/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Darío Fajardo alu0101564630@ull.edu.es
 * @date Jan, 4 2023
 * @brief Robot Simulator
 * @See https://exercism.org/tracks/cpp/exercises/robot-simulator
 */

#include <iostream>
#include "robot_simulator.h"

namespace robot_simulator {

  /**
    * @brief Cambia la orientación del robot hacia la izquierda 
    */
  void Robot::turn_left() {
    switch (bearing_) {
      case Bearing::NORTH:
        bearing_ = Bearing::WEST;
        break;
      case Bearing::EAST:
        bearing_ = Bearing::NORTH;
        break;
      case Bearing::SOUTH:
        bearing_ = Bearing::EAST;
        break;
      case Bearing::WEST:
        bearing_ = Bearing::SOUTH;
        break;
    }
  }

  /**
    * @brief Cambia la orientación del robot hacia la derecha 
    */
  void Robot::turn_right() {
    switch (bearing_) {
      case Bearing::NORTH:
        bearing_ = Bearing::EAST;
        break;
      case Bearing::EAST:
        bearing_ = Bearing::SOUTH;
        break;
      case Bearing::SOUTH:
        bearing_ = Bearing::WEST;
        break;
      case Bearing::WEST:
        bearing_ = Bearing::NORTH;
        break;
    }
  }

  /**
    * @brief Hace que el robot avance en la dirección hacia la que está 
    *        orientado
    */
  void Robot::advance() {
    switch (bearing_) {
      case Bearing::NORTH:
        ++position_.second;
        break;
      case Bearing::SOUTH:
        --position_.second;
        break;
      case Bearing::EAST:
        ++position_.first;
        break;
      case Bearing::WEST:
        --position_.first;
        break;
    }
  }

  /**
    * @brief Ejecuta una secuencia de ordenes pasada por una string
    * @param sequence: la secuencia de ordenes que realizará el simulador de
    *                  robot, 'L' lo girará a la izquierda, 'R' a la derecha y
    *                  'A' hará que el robot avance en la dirección hacia la que
    *                  esté orientado.
    */
  void Robot::execute_sequence(const std::string& sequence) {
    for (const auto& actual_instruction : sequence) {
      switch (actual_instruction) {
        case 'L':
          turn_left();
          break;
        case 'R':
          turn_right();
          break;
        case 'A':
          advance();
          break;
      }
    }
  }

}  // namespace robot_simulator
