/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Dario Fajardo alu0101564630@ull.edu.es 
 * @date Nov 6 2022
 * @brief gives the harmonic number in the position given by user
 *
 * @see https://jutge.org/problems/P59539_en
 */

#include <iostream>
#include <iomanip>

int main() {
  unsigned int number{0};
  std::cin >> number;
  double result{0.0};

  for (double i{1}; i <= number; ++i) {
    result += 1.0/i;
  } 
  std::cout << std::fixed << std::setprecision(4) << result << std::endl;
}
