/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Dario Fajardo alu0101564630@ull.edu.es 
 * @date Nov 6 2022
 * @brief prints all integer numbers between 2 given by user
 *
 * @see https://jutge.org/problems/P97156_en
 */

#include <iostream>

int main() {
  int first_number;
  std::cin >> first_number;
  int second_number;
  std::cin >> second_number;
  
  if (first_number == second_number) {
    std::cout << first_number << std::endl;
    return 0;
  }
  for (int i{first_number}; i <= second_number; ++i) {
    std::cout << i;
    if(i == second_number) {
      break;
    }
    std::cout << ",";
  }
  std::cout << std::endl;
}
