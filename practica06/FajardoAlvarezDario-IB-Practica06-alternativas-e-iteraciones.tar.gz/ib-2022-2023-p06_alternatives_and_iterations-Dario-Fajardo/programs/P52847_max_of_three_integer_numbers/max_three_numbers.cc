/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Dario Fajardo alu0101564630@ull.edu.es
 * @date 23 Oct 2022
 * @brief prints the max of 3 introduced numbers
 */

#include <iostream>

int main() {
  int first_number, second_number, third_number;

  std::cin >> first_number >> second_number >> third_number;

  if (first_number < second_number) {
    first_number = second_number;
  }

  if (first_number < third_number) {
    first_number = third_number;
  }

  std::cout << first_number << std::endl;
}
