/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Dario Fajardo alu0101564630@ull.edu.es 
 * @date nov 7 2022
 * @brief calculates the area for given figures and values
 *
 * @see https://jutge.org/problems/P39057_en 
 */

#include <iostream>
#include <iomanip>

int main() {
  int number_of_descriptions;
  std::cin >> number_of_descriptions;
  std::string description;
  
  while (std::cin >> description) {
    if (description == "rectangle") {
      double base, height;
      std::cin >> base >> height;
      std::cout << std::fixed << std::setprecision(6) << base * height 
      << std::endl; 
    } else if (description == "circle") {
      double radius;
      const double kPi{3.14159265358979};
      std::cin >> radius;
      std::cout << std::fixed << std::setprecision(6) << kPi * radius * radius
      << std::endl;  
    }
  }
}
