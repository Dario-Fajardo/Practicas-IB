/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Dario Fajardo alu0101564630@ull.edu.es 
 * @date Nov 6 2022
 * @brief gives the harmonic number in the position given by user
 *
 * @see https://jutge.org/problems/P59539_en
 */

#include <iostream>

int main() {
  int year;
  std::cin >> year;
  int k{year/100}, x{year % 19}, b{year % 4}, c{year % 7}, q{k / 4}, 
  p{(13 + 8 * k) / 25}, y{(15 - p + k - q) % 30}, z{(19 * x + y) % 30};
}
