/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Dario Fajardo alu0101564630@ull.edu.es 
 * @date nov 6 2022
 * @brief adds one second to time given by user
 *
 * @see https://jutge.org/problems/P34279_en 
 */

#include <iostream>

int main() {
  unsigned int hours;
  std::cin >> hours;
  unsigned int minutes;
  std::cin >> minutes;
  unsigned int seconds;
  std::cin >> seconds;
  ++seconds;

  if (seconds >= 60) {
    unsigned int extra_seconds{seconds / 60};
    seconds = seconds - 60 * extra_seconds;
    minutes = minutes + extra_seconds;
  }
  if (minutes >= 60) {
    unsigned int extra_minutes{minutes / 60};
    minutes = minutes - 60 * extra_minutes; 
    hours = hours + extra_minutes;
  }
  if (hours >= 24) {
    hours = 0;
  }

  if (hours < 10) {
    std::cout << "0";
  }
  std::cout << hours << ":";
  if (minutes < 10) {
    std::cout << "0";
  }
  std::cout << minutes << ":";

  if (seconds < 10) {
    std::cout << "0";
  }
  std::cout << seconds << std::endl;
}
