/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Dario Fajardo alu0101564630@ull.edu.es
 * @date nov 3 2022
 * @brief program turns any lowercase into uppercase and vice versa
 *
 * @see https://jutge.org/problems/P98960_en
 */

#include <iostream>

int main() {
  char letter;
  std::cin >> letter;
  
  if ((static_cast<int>(letter) >= 65) &&
    (static_cast<int>(letter) <= 90)) {
    std::cout << static_cast<char>(static_cast<int>(letter) + 32) << std::endl;
  } else if ((static_cast<int>(letter) >= 97) &&
    (static_cast<int>(letter) <= 122)) {
    std::cout << static_cast<char>(static_cast<int>(letter) - 32) << std::endl;
  }

  return 0;
}
