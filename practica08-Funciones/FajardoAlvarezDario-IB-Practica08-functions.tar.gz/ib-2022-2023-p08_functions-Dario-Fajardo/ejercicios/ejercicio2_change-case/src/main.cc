/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Dario Fajardo alu0101564630@ull.es  
  * @date Nov 19 2022  
  * @brief The main part of the change-case program
  * @bug no bugs knonw
  */

#include <iostream>
#include <stdlib.h>
#include <change-case.h>

int main(int argc, char *argv[]) {
  PrintProgramPurpose();
  if (!CheckCorrectParameters) {
    return 1;
  }
  std::string word{argv[1]};
  std::cout << ChangeCase(word) << std::endl;
}
