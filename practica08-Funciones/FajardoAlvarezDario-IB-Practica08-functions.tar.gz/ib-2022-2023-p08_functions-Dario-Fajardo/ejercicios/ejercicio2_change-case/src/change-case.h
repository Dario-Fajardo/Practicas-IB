/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Dario Fajardo alu0101564630@ull.es
  * @date Nov 19 2022
  * @brief A program that reads a word entered by user and changes uppercases
  * to lowercase and vice versa
  * @bug no bugs known
  */

#include <iostream>

void PrintProgramPurpose();

bool CheckCorrectParameters(const int argc, char *argv[], 
const int kCorrectNumber);

std::string ChangeCase(std::string word);
