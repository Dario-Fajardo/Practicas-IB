/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Dario Fajardo alu0101564630@ull.es
  * @date Nov 19 2022
  * @brief A program that reads a word entered by user and changes uppercases
  * to lowercase and vice versa
  * @bug no bugs known
  */

#include <iostream>
#include <change-case.h>

/**
  * A simple function that prints by console the main purpose of the program
  * in order to help the user undertsand it.
  */
void PrintProgramPurpose() {
  std::cout << "This program changes every uppercase in the input for a ";
  std::cout << "lowercase and vice versa." << std::endl << std::endl;
}

/**
  * A simple function that checks that the number of parameters entered
  * is the expected by the program in order to make everything work well
  *
  * @param argc The number of entered parameters
  * @param argv The entered parameters
  * @param kCorrectNumber  the expected number of parameters
  *
  * @return It returns a true value if everything correct, else, a false value
  * if the number of parameters is not the expected
  */
bool CheckCorrectParameters(const int argc, char *argv[],
const int kCorrectNumber) {
  if (argc != kCorrectNumber) {
    std::cout << "Something went wrong, make sure that you entered the ";
    std::cout << "number of parameters in order to make the program work.";
    std::cout << std::endl << std::endl;
    return false;
  } else {
    std::cout << "Everything OK! Executing normally...\n" << std::endl;
    return true;
  }
}

std::string ChangeCase(std::string word) {
  int length{word.size()};
  for (int i{0}; i < length; ++i) {
    if ((word[i] >= 65) && (word[i] <= 90)) {
      word[i] += 32;
    } else {
      word[i] -= 32;
    }
  }
  return word;
}
