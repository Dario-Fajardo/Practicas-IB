/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Dario Fajardo alu0101564630@ull.es  
  * @date  
  * @brief 
  * @bug no bugs knonw
  * @see 
  */

#include <iostream>

/**
  * A function that sums all the squares until reaching an specific number
  * 
  * @param number The last number
  */
int SquaresSum(int number) {
  int result{0};
  for (int i{1}; i <= number; ++i) {
   result = result + i * i;
  }
  return result;
}

int main() {
  int number;
  std::cin >> number;
  std::cout << SquaresSum(number) << std::endl;
  return 0;
}
