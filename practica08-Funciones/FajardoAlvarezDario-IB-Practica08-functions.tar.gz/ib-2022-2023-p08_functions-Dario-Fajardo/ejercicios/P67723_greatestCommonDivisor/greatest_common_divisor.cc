/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Dario Fajardo alu0101564630@ull.es  
  * @date Nov 21 2022
  * @brief Calculates the greatest common divisor of two numbers 
  * @bug no bugs knonw
  * @see https://jutge.org/problems/P67723_en
  */

#include <iostream>

/**
  * This function calculates the greates common divisor of two numbers
  * 
  * @param first_number second_number The two numbers
  */
int GreatestCommonDivisor(int first_number, int second_number) {
  if (first_number > second_number) {
    int auxiliar{first_number};
    first_number = second_number;
    second_number = auxiliar;
  }
  int divisor;
  for (int i{0}; i <= second_number; ++i) {
    if ((first_number % i == 0) && (second_number % i == 0)) {
      divisor = i;
    }
  }
  return divisor;
}

int main() {
  int first_number, second_number;
  std::cin >> first_number >> second_number;
  std::cout << "The gcd of " << first_number << " and " << second_number;
  std::cout << " is ";
  std::cout << GreatestCommonDivisor(first_number, second_number) << ".";
  std::cout << std::endl;
  return 0;
}
