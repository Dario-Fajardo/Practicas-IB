/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Dario Fajardo alu0101564630@ull.es  
  * @date Nov 20 2022  
  * @brief this program gives the area of a triangle using Heron's formule
  * @bug no bugs known
  * @see https://en.wikipedia.org/wiki/Heron%27s_formula
  */

#include <iostream>
#include <cmath>
#include <iomanip>

/**
  * A simple function that prints by console the main purpose of the program
  * in order to help the user undertsand it.
  */
void PrintProgramPurpose() {
  std::cout << "This program will calculate the area of the entered triangle ";
  std::cout << "only if it satisfies the trangle inequality";
}

/**
  * A simple function that checks that the number of parameters entered
  * is the expected by the program in order to make everything work well
  *
  * @param argc The number of entered parameters
  * @param argv The entered parameters
  * @param kCorrectNumber  the expected number of parameters
  *
  * @return It returns a true value if everything correct, else, a false value
  * if the number of parameters is not the expected
  */
bool CheckCorrectParameters(const int argc, char *argv[], 
const int kCorrectNumber) {
  if (argc != kCorrectNumber) {
    std::cout << "Something went wrong, make sure that you entered the correct ";
    std::cout << "number of parameters in order to make the program work.";
    std::cout << std::endl << std::endl;
    return false;
  } else {
    std::cout << "Everything OK! Executing normally...\n" << std::endl;
    return true;
  }
}

/**
  * Just a simple function that checks if a triangle is valid or not
  * 
  * @param side_a, side_b, side_c The three sides of the triangle
  */
void IsAValidTriangle(int side_a, int side_b, int side_c){
  if ((side_a > side_b + side_c) || (side_b > side_a + side_c) 
  || (side_c > side_a + side_b)) {
    std::cout << "The entered triangle is not valid, please make sure that ";
    std::cout << "no side is bigger than the sum of the other two";
    std::cout << std::endl << std::endl;
  }
}

/**
  * This function calculates the area of a triangle using Heron's formule
  * 
  * @param side_a, side_b, side_c The three sides of the triangle
  */
double Area(double side_a, double side_b, double side_c) {
  double semiperimeter{(side_a + side_b + side_c) / 2};
  double area{sqrt(semiperimeter * (semiperimeter - side_a) * 
  (semiperimeter - side_b) * (semiperimeter - side_c))};
  return area;
}

int main(int argc, char *argv[]) {
  PrintProgramPurpose();
  CheckCorrectParameters(argc, argv, 4);
  if (!CheckCorrectParameters(argc, argv, 4)) {
    return 1;
  }
  double side_a{atof(argv[1])}, side_b{atof(argv[2])}, side_c{atof(argv[3])};
  IsAValidTriangle(side_a, side_b, side_c);
  std::cout << std::fixed << std::setprecision(2);
  std::cout << Area(side_a, side_b, side_c);
  std::cout << std::endl << std::endl;
}
