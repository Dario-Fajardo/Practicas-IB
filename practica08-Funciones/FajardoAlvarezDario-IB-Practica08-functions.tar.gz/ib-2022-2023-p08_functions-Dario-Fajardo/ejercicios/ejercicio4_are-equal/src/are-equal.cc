/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Dario Fajardo alu0101564630@ull.es  
  * @date Nov 20 2022 
  * @brief This program compare two numbers and says if theya re equal or not
  * @bug no bugs knonw
  */

#include <iostream>
#include <stdlib.h>
#include <cmath>

/**
  * A simple function that prints by console the main purpose of the program
  * in order to help the user undertsand it.
  */
void PrintProgramPurpose() {
  std::cout << "This program will print if the entered numbers ar equal or not";
}

/**
  * A simple function that checks that the number of parameters entered
  * is the expected by the program in order to make everything work well
  *
  * @param argc The number of entered parameters
  * @param argv The entered parameters
  * @param kCorrectNumber  the expected number of parameters
  *
  * @return It returns a true value if everything correct, else, a false value
  * if the number of parameters is not the expected
  */
bool CheckCorrectParameters(const int argc, char *argv[], 
const int kCorrectNumber) {
  if (argc != kCorrectNumber) {
    std::cout << "Something went wrong, make sure that you entered the correct";
    std::cout << "number of parameters in order to make the program work.";
    std::cout << std::endl << std::endl;
    return false;
  } else {
    std::cout << "Everything OK! Executing normally...\n" << std::endl;
    return true;
  }
}

/**
  * This function compares two numbers and says if they are equal or not
  * 
  * @param number1 The first number
  * @param number2 The second number
  * @param epsilon The value that the function will take as error range
  *
  * @return True if numbers are equal or False if they are not
  */
bool AreEqual(const double number1, const double number2, const double epsilon = 1e-7) {
  if (abs(number1 - number2 ) < epsilon) {
    return true;
  } else {
    return false;
  }
}

int main(int argc, char *argv[]) {
  PrintProgramPurpose();
  CheckCorrectParameters(argc, argv, 3);
  if (!CheckCorrectParameters(argc, argv, 3)) {
    return 1;
  }
  double first_number{atof(argv[1])}, second_number{atof(argv[2])};
  if (AreEqual(first_number, second_number)) {
    std::cout << "EQUAL" << std::endl;
  } else {
    std::cout << "NOT EQUAL" << std::endl;
  }
}
