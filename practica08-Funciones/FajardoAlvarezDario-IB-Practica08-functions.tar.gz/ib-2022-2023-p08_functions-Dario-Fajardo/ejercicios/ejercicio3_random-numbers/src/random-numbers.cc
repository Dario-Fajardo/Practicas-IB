/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Dario Fajardo alu0101564630@ull.es  
  * @date Nov 20 2022 
  * @brief This program generates a random number between another two 
  * given numbers
  * @bug no bugs knonw
  */

#include <iostream>
#include <cstdlib>
#include <ctime>

/**
  * A simple function that prints by console the main purpose of the program
  * in order to help the user undertsand it.
  */
void PrintProgramPurpose() {
  std::cout << "This program will print a random number between two";
  std::cout << "numbers given by the user";
}

/**
  * A simple function that checks that the number of parameters entered
  * is the expected by the program in order to make everything work well
  *
  * @param argc The number of entered parameters
  * @param argv The entered parameters
  * @param kCorrectNumber  the expected number of parameters
  *
  * @return It returns a true value if everything correct, else, a false value
  * if the number of parameters is not the expected
  */
bool CheckCorrectParameters(const int argc, char *argv[], 
const int kCorrectNumber) {
  if (argc != kCorrectNumber) {
    std::cout << "Something went wrong, make sure that you entered the ";
    std::cout << "number of parameters in order to make the program work.";
    std::cout << std::endl << std::endl;
    return false;
  } else {
    std::cout << "Everything OK! Executing normally...\n" << std::endl;
    return true;
  }
}

/**
  * This function generates a random number between two defined integers
  * 
  * @param first_number The minimum number
  * @param second_number The maximum number
  * 
  * @return It returns a number generated between the other two
  */
int RandomNumber(int first_number, int second_number) {
  std::srand(std::time(NULL));
  int random{first_number + std::rand() % (second_number + 1 - first_number)};
  return random;
}

int main(int argc, char *argv[]) {
  PrintProgramPurpose();
  CheckCorrectParameters(argc, argv, 3);
  if (!CheckCorrectParameters(argc, argv, 3)) {
    return 1;
  }
  int first_number{atoi(argv[1])}, second_number{atoi(argv[2])};
  if (second_number <= first_number) {
    std::cout << "The second number must be bigger than the second one\n";
    return 2;
  }
  std::cout << RandomNumber(first_number, second_number) << std::endl;
  return 0;
}

