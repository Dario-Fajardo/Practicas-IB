/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2022-2023
  *
  * @author Dario Fajardo alu0101564630@ull.es  
  * @date Nov 17 2022  
  * @brief evaluates 3 values in a 3 variable function (see the link)
  * @bug no bugs knonw
  * @see https://github.com/IB-2022-2023/P08-functions/raw/main/functionG.png
  */

#include <iostream>
#include <stdlib.h>
#include <cmath>

/**
  * inputs three values into a function and evaluates them
  * 
  * @param first_number first value (x)
  * @param second_number second value (y)
  * @param third_number third value (t)
  * 
  * @see https://github.com/IB-2022-2023/P08-functions/raw/main/functionG.png
  */
double Function(double first_number, double second_number, 
double third_number) {
  double result;
  result = (sqrt(2 * third_number - 4)) / ((first_number * first_number) - 
  (second_number * second_number));
  return result;
}

/**
  * A simple function that prints what does de program do
  */
void PrintProgramPurpose() {
  std::cout << "This program evaluates 3 variable values introduced ";
  std::cout << "by the user." << std::endl;
  std::cout << "Now, the program will check if the values you entered ";
  std::cout << "are correct..." << std::endl;
}

/**
  * A simple function that checks the number of parameters entered by the user
  * is correct
  * 
  * @param argc the number of parameters entered
  * @param argv[] the entered parameters
  * @param kCorrectNumber the correcrt number of parameters
  *
  * @return if everything is ok it returns true, else it returns a false value
  */
bool CheckCorrectParameters(const int argc, char *argv[], 
const int kCorrectNumber) {
  if (argc != kCorrectNumber){
    return false;
  }
  return true;
}

int main(int argc, char *argv[]) {
  PrintProgramPurpose();
  if (!CheckCorrectParameters(argc, argv, 4)) {
    std::cout << "Something went wrong, make sure you entered 3 ";
    std::cout << "valid numbers..." << std::endl;
    return 345;
  } else {
    std::cout << "Everything OK! executing..." << std::endl;
  }
  std::cout << Function(atof(argv[1]), atof(argv[2]), atof(argv[3])) << std::endl;
}
