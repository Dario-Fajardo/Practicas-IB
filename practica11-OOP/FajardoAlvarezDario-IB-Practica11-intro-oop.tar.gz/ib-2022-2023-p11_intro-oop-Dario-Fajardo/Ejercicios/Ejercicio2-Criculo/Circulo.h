/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Dario Fajardo alu0101564630@ull.edu.es
 * @date 18 Dic 2022
 * @brief Este programa permite tomar y representar circulos mediante distintos
 *        atributos y metodos.
 */

#include <iostream>
#include <string>

#ifndef Circulo_H
#define Circulo_H

class Circulo{
 public:
  enum class Color {Rojo, Verde, Azul};
  Circulo();
  Circulo(double x_coord, double y_coord, double radius, Color color);
  void Show(int circle_number);
  void Area(int circle_number);
  void Perimetro(int circle_number);
  void Print(int circle_number);
  void IsInterior(double x_coord, double y_coord);

 private:
  double x_coord_;
  double y_coord_;
  double radius_;
  Color color_;
};

#endif