/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es
  * @date 18 Dic 2022
  * @brief Este programa permite tomar y representar circulos mediante distintos
  *        atributos y metodos.
  */

#include <iostream>
#include <string>
#include <stdlib.h>
#include "Circulo.h"

int main() {
  Circulo circle1(1, 2, 3, Circulo::Color::Rojo);
  Circulo circle2(4, 5, 6, Circulo::Color::Verde);
  Circulo circle3(7, 8, 9, Circulo::Color::Azul);

  circle1.Show(1);
  circle2.Show(2);
  circle3.Show(3);

  circle1.Area(1);
  circle2.Area(2);
  circle3.Area(3);

  circle1.Perimetro(1);
  circle2.Perimetro(2);
  circle3.Perimetro(3);

  circle1.Print(1);
  circle2.Print(2);
  circle3.Print(3);

  circle1.IsInterior(1, 2);
  circle2.IsInterior(4, 5);
  circle3.IsInterior(0, 0);

  return 0;
}