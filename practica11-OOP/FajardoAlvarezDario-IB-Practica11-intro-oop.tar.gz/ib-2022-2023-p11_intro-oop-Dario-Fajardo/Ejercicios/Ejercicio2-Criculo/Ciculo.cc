/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es
  * @date 18 Dic 2022
  * @brief Este programa permite tomar y representar circulos mediante distintos
  *        atributos y metodos.
  */

#include <iostream>
#include <string>
#include <cmath>
#include "Circulo.h"

/**
  * @brief constructor por defecto
  */
Circulo::Circulo() : x_coord_{0}, y_coord_{0}, radius_{0}, color_{Color::Rojo} {
  std::cout << "DEBUG: Constructor Circulo por DEFECTO ejecutado" << std::endl;
}

/**
  * @brief constructor con parametros
  */
Circulo::Circulo(double x_coord, double y_coord, double radius, Color color) : 
x_coord_{x_coord}, y_coord_{y_coord}, radius_{radius}, color_{color} {
  std::cout << "DEBUG: Constructor Circulo con PARAMETROS ejecutado";
  std::cout << std::endl;
}

/**
  * @brief metodo para mostrar las coordenadas del punto
  * @param circle_number: un numero usado como identificador del circulo
  */
void Circulo::Show(int circle_number) {
  std::cout << "El circulo " << circle_number;
  std::cout << " tiene las coordenadas: (" << x_coord_ << ", ";
  std::cout << y_coord_ << ")" << std::endl;
}

/**
  * @brief metodo para calcular el area del circulo
  * @param circle_number: un numero usado como identificador del circulo
  */
void Circulo::Area(int circle_number) {
  double area = M_PI * pow(radius_, 2);
  std::cout << "El area del circulo " << circle_number << " es: " << area;
  std::cout << std::endl;
}

/**
  * @brief metodo para calcular el perimetro del circulo
  * @param circle_number: un numero usado como identificador del circulo
  */
void Circulo::Perimetro(int circle_number) {
  double perimetro = 2 * M_PI * radius_;
  std::cout << "El perimetro del circulo " << circle_number << " es: "; 
  std::cout  << perimetro << std::endl;
}

/**
  * @brief metodo para imprimir el color del circulo
  * @param circle_number: un numero usado como identificador del circulo
  */
void Circulo::Print(int circle_number) {
  switch (color_)
  {
  case Color::Rojo:
    std::cout << "El color del circulo " << circle_number << " es: Rojo";
    std::cout << std::endl;
    break;
  case Color::Verde:
    std::cout << "El color del circulo " << circle_number << " es: Verde";
    std::cout << std::endl;
    break;
  case Color::Azul:
    std::cout << "El color del circulo " << circle_number << " es: Azul";
    std::cout << std::endl;
    break;
  }
}

/**
  * @brief metodo para comprobar si un punto esta dentro del circulo
  * @param point_x: la coordenada x del punto
  * @param point_y: la coordenada y del punto 
  */
void Circulo::IsInterior(double point_x, double point_y) {
  double distancia = sqrt(pow(point_x - x_coord_, 2) + pow(point_y - y_coord_, 2));
  if (distancia <= radius_)
  {
    std::cout << "El punto (" << point_x << ", " << point_y;
    std::cout << ") esta dentro del circulo" << std::endl;
  }
  else
  {
    std::cout << "El punto (" << point_x << ", " << point_y;
    std::cout << ") esta fuera del circulo" << std::endl;
  }
}