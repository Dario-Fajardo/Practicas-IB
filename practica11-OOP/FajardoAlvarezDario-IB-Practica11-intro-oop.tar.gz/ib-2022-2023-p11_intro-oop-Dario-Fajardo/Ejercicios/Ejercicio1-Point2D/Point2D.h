/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es
  * @date 18 Dic 2022
  * @brief Este programa representa puntos en el espacio bidimensional a traves
  *        de sus coordenadas
  */

#ifndef POINT2D_H
#define POINT2D_H

class Point2D {
 public:
  Point2D();
  Point2D(double x_coord, double y_coord);
  void Show(int point_number);
  void Move(double x_coord, double y_coord);
  double Distance(Point2D point);
  Point2D Middle(Point2D point);

 private:
  double x_coord_;
  double y_coord_;
};

#endif