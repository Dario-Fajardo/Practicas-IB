/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es
  * @date 18 Dic 2022
  * @brief Este programa representa puntos en el espacio bidimensional a traves
  *        de sus coordenadas
  */

#include <iostream>
#include <string>
#include <cmath>

#include "Point2D.h"

/**
  * @brief constructor por defecto
  */
Point2D::Point2D() : x_coord_{0}, y_coord_{0} {
	std::cout << "DEBUG: Constructor Point2D por DEFECTO ejecutado" << std::endl;
}

/**
  * @brief constructor con parametros
  * @param x_coord: la coordenada x del punto 2D
  * @param y_coord: la coordenada y del punto 2D
  */
Point2D::Point2D(double x_coord, double y_coord) : x_coord_{x_coord},
y_coord_{y_coord} {
	std::cout << "DEBUG: Constructor Point2D con PARAMETROS ejecutado";
	std::cout << std::endl;
}

/**
  * @brief metodo para mostrar las coordenadas del punto
  * @param point_number: un numero que sirve como identificador del punto
  */
void Point2D::Show(int point_number) {
	std::cout << "Las coordenadas del punto" << point_number << " son: (";
	std::cout << x_coord_ << ", " << y_coord_ << ")" << std::endl;
}

/**
	* @brief metodo para mover las coordenadas del punto
	* @param x_coord: la nueva coordenada x
	* @param y_coord: la nueva coordenada y
	*/
void Point2D::Move(double x_coord, double y_coord) {
	x_coord_ = x_coord;
	y_coord_ = y_coord;

	std::cout << "Las coordenadas del punto han sido cambiadas a: (";
	std::cout << x_coord_ << ", " << y_coord_ << ")" << std::endl;
}

/**
 * @brief metodo para calcular la distancia entre dos puntos
 * @param point: el punto
 * @return distance: la distancia entre dos puntos
 */
double Point2D::Distance(Point2D point) {
	double distance = sqrt(pow((point.x_coord_ - x_coord_), 2) + 
	pow((point.y_coord_ - y_coord_), 2));
	return distance;
}

/**
  * @brief metodo para calcular el punto medio entre dos puntos
  * @param point: el punto
  * @return middle: el punto medio
  */
Point2D Point2D::Middle(Point2D point) {
	double middle_x = (point.x_coord_ + x_coord_) / 2;
	double middle_y = (point.y_coord_ + y_coord_) / 2;
	Point2D middle(middle_x, middle_y);
	return middle;
}