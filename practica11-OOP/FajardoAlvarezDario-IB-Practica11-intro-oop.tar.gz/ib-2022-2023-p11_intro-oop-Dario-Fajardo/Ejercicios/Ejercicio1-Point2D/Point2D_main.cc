/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es
  * @date 18 Dic 2022
  * @brief Este programa representa puntos en el espacio bidimensional a traves
  *        de sus coordenadas
  */
 
#include <iostream>
#include "Point2D.h"

int main() {
  Point2D point1(5, 1);
  Point2D point2(2, 0);
  point1.Show(1);
  point2.Show(2);
  point1.Move(5, 6);
  point1.Show(1);
  std::cout << "La distancia entre los puntos es: " << point1.Distance(point2);
  std::cout << std::endl;
  Point2D point3 = point1.Middle(point2);
  point3.Show(3);
  return 0;
}