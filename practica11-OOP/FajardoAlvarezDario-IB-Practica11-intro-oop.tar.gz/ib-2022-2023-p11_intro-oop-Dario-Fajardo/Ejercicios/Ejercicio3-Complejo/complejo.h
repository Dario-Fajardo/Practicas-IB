/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es
  * @date 18 Dic 2022
  * @brief Este programa permite tratar con numeros complejos en forma binomica
  */

#ifndef COMPLEJO_H
#define COMPLEJO_H

#include <iostream>
#include <string>
#include <cmath>

class Complejo {
 public:
  Complejo();
  Complejo(const double real, const double imaginario);
  double real() const { return real_; }
  double imaginario() const { return imaginario_; }
  Complejo operator+(const Complejo& complejo) const;
  Complejo operator-(const Complejo& complejo) const;
  Complejo operator*(const Complejo& complejo) const;
  Complejo operator/(const Complejo& complejo) const;
  friend std::ostream& operator<<(std::ostream& output, const Complejo& complejo);
 private:
  double real_{0};
  double imaginario_{0};
};

#endif