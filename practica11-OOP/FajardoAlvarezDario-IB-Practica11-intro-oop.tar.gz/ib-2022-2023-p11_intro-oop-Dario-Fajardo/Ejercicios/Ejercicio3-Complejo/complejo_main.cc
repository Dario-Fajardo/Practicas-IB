/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es
  * @date 18 Dic 2022
  * @brief Este programa permite tratar con numeros complejos en forma binomica
  */

#include "complejo.h"

int main() {
  Complejo complejo1(1, 2);
  Complejo complejo2(3, 4);
  Complejo resultado;
  std::cout << "Complejo 1: " << complejo1 << std::endl;
  std::cout << "Complejo 2: " << complejo2 << std::endl;
  resultado = complejo1 + complejo2;
  std::cout << "Suma: " << resultado << std::endl;
  resultado = complejo1 - complejo2;
  std::cout << "Resta: " << resultado << std::endl;
  resultado = complejo1 * complejo2;
  std::cout << "Multiplicaion: " << resultado << std::endl;
  resultado = complejo1 / complejo2;
  std::cout << "Division: " << resultado << std::endl;
  return 0;
}