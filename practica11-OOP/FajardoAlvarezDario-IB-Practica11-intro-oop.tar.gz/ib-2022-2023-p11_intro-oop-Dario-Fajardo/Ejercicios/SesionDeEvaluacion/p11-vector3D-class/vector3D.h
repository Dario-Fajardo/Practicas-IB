/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author F de Sande
 * @date Dec 16 2022
 * @brief Vector3D class Definition
 */

#ifndef VECTOR3D_H
#define VECTOR3D_H

/** @brief Class Vector3D */
class Vector3D {
 public:
  Vector3D() : x_coord_{0.0}, y_coord_{0.0}, z_coord_{0.0} {}
  friend std::ostream& operator<<(std::ostream& kOutput, 
  const Vector3D& vector1);
  // 3 Getters:
  double x_position() const { 
    return x_coord_;
  } 
  double y_position() const { 
      return y_coord_; 
    }
  double z_position() const { 
    return z_coord_; 
  }
 private:
  double x_coord_;
  double y_coord_;
  double z_coord_;
};

#endif
