/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es
  * @date 18 Dic 2022
  * @brief Este programa permite tratar y gestionar fechas mediante una clase
  */

#include "fecha.h"

/**
 * @brief Constructor por defecto 
 */
Fecha::Fecha() {}

/**
 * @brief Constructor con parametros 
 */
Fecha::Fecha(const int dia, const int mes, const int anio) {
  dia_ = dia;
  mes_ = mes;
  anio_ = anio;
}

/**
 * @brief Comprueba si el año es bisiesto
 * @return true si es bisiesto, false si no
 */
bool Fecha::es_bisiesto() const {
  if (anio_ % 4 == 0 && anio_ % 100 != 0 || anio_ % 400 == 0)
  {
    return true;
  }
  else
  {
    return false;
  }
}

/**
 * @brief Comprueba si la fecha introducida tiene un formato valido 
 * @return true si la fecha es valida, false si no
 */
bool Fecha::es_valida() const {
  if (dia_ < 1 || mes_ < 1 || anio_ < 1800 || anio_ > 9999 || mes_ > 12 ||
      dia_ > 31)
  {
    return false;
  }
  if (!es_bisiesto() && mes_ == 2 && dia_ > 28)
  {
    return false;
  }
  if (mes_ == 2 && dia_ > 29)
  {
    return false;
  }
  if ((mes_ > 7 && mes_ % 2 != 0 && dia_ > 30) ||
      (mes_ <= 7 && mes_ % 2 == 0 && dia_ > 30))
  {
    return false;
  }
  return true;
}

std::ostream &operator<<(std::ostream &output, const Fecha &fecha)
{
  output << fecha.dia_ << "/" << fecha.mes_ << "/" << fecha.anio_;
  return output;
}

std::istream &operator>>(std::istream &input, Fecha &fecha)
{
  input >> fecha.dia_ >> fecha.mes_ >> fecha.anio_;
  return input;
}
