/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es
  * @date 18 Dic 2022
  * @brief Este programa permite tratar y gestionar fechas mediante una clase
  */

#ifndef FECHA_H
#define FECHA_H

#include <iostream>
#include <string>
#include <cmath>

class Fecha {
 public:
	Fecha();
	Fecha(const int dia, const int mes, const int anio);
	bool es_bisiesto() const;
	bool es_valida() const;
	friend std::ostream &operator<<(std::ostream &os, const Fecha &fecha);
	friend std::istream &operator>>(std::istream &is, Fecha &fecha);

 private:
  int dia_{0};
	int mes_{0};
	int anio_{0};
};

#endif