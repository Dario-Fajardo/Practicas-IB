/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es
  * @date 18 Dic 2022
  * @brief Este programa contiene una funcion capaz de saber si una fecha
  *        es valida o no
  * @see https://jutge.org/problems/P58459_en
  */

/**
  * @brief Comprueba si un año es bisiesto o no
  * @param year: el año a comprobar
  * @return true si es bisiesto, false si no
  */
bool IsLeap(int year) {
    if (year % 4 == 0 && year % 100 != 0 || year % 400 == 0)
  {
    return true;
  }
  else
  {
    return false;
  }
}

/**
  * @brief Comprueba si la fecha introducida tiene un formato valido 
  * @return true si la fecha es valida, false si no
  */
bool is_valid_date(int day, int month, int year) {
  if (day < 1 || month < 1 || year < 1800 || year > 9999 || month > 12 || 
  day > 31)
  {
    return false;
  }
  if (!IsLeap(year) && month == 2 && day > 28)
  {
    return false;
  }
  if (month == 2 && day > 29)
  {
    return false;
  }
  if ((month > 7 && month % 2 != 0 && day > 30) ||
      (month <= 7 && month % 2 == 0 && day > 30))
  {
    return false;
  }
  return true;
}