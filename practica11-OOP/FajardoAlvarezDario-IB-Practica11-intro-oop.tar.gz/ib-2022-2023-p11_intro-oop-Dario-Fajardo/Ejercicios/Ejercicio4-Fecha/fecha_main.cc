/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica
  *
  * @author Dario Fajardo alu0101564630@ull.edu.es
  * @date 18 Dic 2022
  * @brief Este programa permite tratar y gestionar fechas mediante una clase
  */

#include "fecha.h"

int main() {
  Fecha fecha1(1, 2, 2020);
  Fecha fecha2(3, 4, 2121);
  Fecha resultado;
  std::cout << "Fecha 1: " << fecha1 << std::endl;
  std::cout << "Fecha 2: " << fecha2 << std::endl;
  std::cout << "Fecha 1 es bisiesto: ";
  if (fecha1.es_bisiesto() == true) {
    std::cout << "yes";
  } else {
    std::cout << "no";
  }
  std::cout << std::endl;
  std::cout << "Fecha 2 es bisiesto: ";
  if (fecha2.es_bisiesto() == true) {
    std::cout << "yes";
  } else {
    std::cout << "no";
  }
  std::cout << std::endl;
  std::cout << "Fecha 1 es valida: ";
  if (fecha1.es_valida() == true) {
    std::cout << "yes";
  } else {
    std::cout << "no";
  }
  std::cout << std::endl;
  std::cout << "Fecha 2 es valida: ";
  if (fecha2.es_valida() == true) {
    std::cout << "yes";
  } else {
    std::cout << "no";
  }
  std::cout << std::endl;
  return 0;
}